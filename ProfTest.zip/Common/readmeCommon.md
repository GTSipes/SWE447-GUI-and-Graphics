#SWE447-GUI-and-Graphics/Common/

This readme is the main readme for the Common section. This directory contains files that are included in each WebGL app.
