Readme file for assignmemt 2.
